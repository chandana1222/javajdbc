package Demo;
import java.sql.*;

public class JdbcExample {
	public static void main(String[] args) throws SQLException {
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/emp","root","Snehitha@99");
		Statement stmt=con.createStatement();
		
		String s="INSERT INTO emp VALUES(30,'NAINA','DOBREV')";
		String s1="INSERT INTO emp VALUES(40, 'SNEHITHA','PORANKI')";
		String s2="INSERT INTO emp VALUES(50, 'CHANDANA', 'MITAPALLY')";
		String s3="INSERT INTO emp VALUES(60, 'BHAVANA', 'PORANKI')";	
		String s4="UPDATE emp SET firstname='DAVID' WHERE ID=30";
		String s5="DELETE FROM emp WHERE ID=50";
		stmt.execute(s);
		stmt.execute(s1);
		stmt.execute(s2);
		stmt.execute(s3);
		stmt.execute(s4);
		stmt.execute(s5);
		
		
		con.close();
		
		System.out.println("Query Executed....");
	}
}

