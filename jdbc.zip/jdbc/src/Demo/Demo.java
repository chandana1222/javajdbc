package Demo;
import java.sql.*;
public class Demo {
public static void main(String[] args) {
// TODO Auto-generated method stub
try {
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/tree","root","Snehitha@99");
Statement stmt=con.createStatement();
System.out.println(" connection created");
String sql="create table student(roll no int, name varchar(50))";
Statement st=con.createStatement();
System.out.println("Statement created");
String query = null;
st.execute(query);
System.out.println("Table created");
stmt.execute(sql);
}
catch(Exception e) {
System.out.println("Connection created");
}
}
}